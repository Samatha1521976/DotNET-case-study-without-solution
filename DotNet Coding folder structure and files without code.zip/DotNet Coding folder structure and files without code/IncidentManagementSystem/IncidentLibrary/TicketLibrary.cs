﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IncidentLibrary
{
    public class TicketLibrary
    {
     public   List<Ticket> ticketarray;
        public TicketLibrary() {
                    
        }

        public void AddTicket(Ticket ticket)
        {
            
        }

        public List<Ticket> GetAllTickets()
        {
            
        }

        public bool GetTicketById(int id)
        {
               
        }


    }
}
