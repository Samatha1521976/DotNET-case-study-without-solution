﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using IncidentLibrary;

namespace Inicident_UI
{
    internal class ExecuteTicket
    {
               public ExecuteTicket()
        {
        
        }
        public void Menu()
        {
            
        }

        public void AddTicketDetails()
        {
        
}

        public void PrintAllTickets()
        {
            
        }

        public void GetTicketById()
        {
            
        }
    }
}
